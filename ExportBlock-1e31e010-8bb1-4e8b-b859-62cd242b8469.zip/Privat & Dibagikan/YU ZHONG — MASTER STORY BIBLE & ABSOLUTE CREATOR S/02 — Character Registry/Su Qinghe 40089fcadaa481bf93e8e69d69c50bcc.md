# Su Qinghe

Character ID: CHR-14
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Pengumpulan Qi
Cultivation Stage: Akhir
Current Location: Reruntuhan Istana Fajar
Faction: Persatuan Penjelajah Reruntuhan
Goals: Menyusun peta reruntuhan yang dapat digunakan ekspedisi berikutnya.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Juru peta muda; catatan lapangannya belum dianggap otoritatif.
Last Updated Chapter: 0
Personality: Berani, mudah bersemangat, tetap menghormati prosedur keselamatan.
Role: Supporting
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Berani, mudah bersemangat, tetap menghormati prosedur keselamatan.

**Tujuan pribadi:** Menyusun peta reruntuhan yang dapat digunakan ekspedisi berikutnya.

**Fakta terkonfirmasi:** Juru peta muda; catatan lapangannya belum dianggap otoritatif.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.