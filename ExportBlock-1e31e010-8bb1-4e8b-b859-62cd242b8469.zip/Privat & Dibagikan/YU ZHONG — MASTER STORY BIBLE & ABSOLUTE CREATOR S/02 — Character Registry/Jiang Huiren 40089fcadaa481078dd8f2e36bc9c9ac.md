# Jiang Huiren

Character ID: CHR-15
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Abadi Emas
Cultivation Stage: Awal
Current Location: Dataran Teratai
Faction: Klan Akar Emas
Goals: Mencegah penebangan pohon roh tua tanpa pemeriksaan dampak.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pengelola kebun roh keluarga; tidak terikat dengan alur utama.
Last Updated Chapter: 0
Personality: Sabar, konservatif, sangat melindungi warisan keluarga.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Sabar, konservatif, sangat melindungi warisan keluarga.

**Tujuan pribadi:** Mencegah penebangan pohon roh tua tanpa pemeriksaan dampak.

**Fakta terkonfirmasi:** Pengelola kebun roh keluarga; tidak terikat dengan alur utama.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.