# Shen Qirong

Character ID: CHR-8
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Dewa Sejati
Cultivation Stage: Awal
Current Location: Jurang Senja
Faction: Kekaisaran Bayang Bintang
Goals: Memperluas pengaruh melalui kontrak dan kompromi yang menguntungkan dirinya.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Tokoh politik berbahaya, tetapi tidak memiliki misi khusus terhadap Yu Zhong.
Last Updated Chapter: 0
Personality: Sabar, manipulatif, mengutamakan keuntungan politik.
Role: Antagonist
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Sabar, manipulatif, mengutamakan keuntungan politik.

**Tujuan pribadi:** Memperluas pengaruh melalui kontrak dan kompromi yang menguntungkan dirinya.

**Fakta terkonfirmasi:** Tokoh politik berbahaya, tetapi tidak memiliki misi khusus terhadap Yu Zhong.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.