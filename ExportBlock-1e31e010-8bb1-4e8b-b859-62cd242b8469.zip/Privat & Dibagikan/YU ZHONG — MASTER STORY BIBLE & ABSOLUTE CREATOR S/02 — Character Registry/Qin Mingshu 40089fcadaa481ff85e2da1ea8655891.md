# Qin Mingshu

Character ID: CHR-5
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Raja Abadi
Cultivation Stage: Awal
Current Location: Dataran Arunika
Faction: Kekaisaran Bintang Arunika
Goals: Menjaga agar sengketa provinsi tidak berkembang menjadi perang besar.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Utusan kekaisaran senior; bukan penguasa tertinggi.
Last Updated Chapter: 0
Personality: Diplomatis, berhitung, menghargai stabilitas.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Diplomatis, berhitung, menghargai stabilitas.

**Tujuan pribadi:** Menjaga agar sengketa provinsi tidak berkembang menjadi perang besar.

**Fakta terkonfirmasi:** Utusan kekaisaran senior; bukan penguasa tertinggi.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.