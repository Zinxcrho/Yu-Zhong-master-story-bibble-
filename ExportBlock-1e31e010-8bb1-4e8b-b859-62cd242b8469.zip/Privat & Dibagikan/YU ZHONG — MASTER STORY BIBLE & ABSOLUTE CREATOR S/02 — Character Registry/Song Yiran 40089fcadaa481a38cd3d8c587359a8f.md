# Song Yiran

Character ID: CHR-24
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Pembukaan Meridian
Cultivation Stage: Menengah
Current Location: Hutan Seribu Akar
Faction: Klan Seribu Daun
Goals: Mengembangkan kebun ramuan yang tidak merusak habitat binatang roh.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Penjaga kebun yang mencatat siklus tumbuh dan panen.
Last Updated Chapter: 0
Personality: Lembut, teliti, tegas mengenai konservasi.
Role: Supporting
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Lembut, teliti, tegas mengenai konservasi.

**Tujuan pribadi:** Mengembangkan kebun ramuan yang tidak merusak habitat binatang roh.

**Fakta terkonfirmasi:** Penjaga kebun yang mencatat siklus tumbuh dan panen.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.