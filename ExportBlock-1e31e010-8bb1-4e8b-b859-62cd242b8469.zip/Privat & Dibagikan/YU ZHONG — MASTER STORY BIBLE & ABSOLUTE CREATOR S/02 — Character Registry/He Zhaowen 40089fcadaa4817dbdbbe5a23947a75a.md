# He Zhaowen

Character ID: CHR-25
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Kaisar Abadi
Cultivation Stage: Menengah
Current Location: Tanah Pintu Selatan
Faction: Kekaisaran Gerbang Kosmik
Goals: Menyelidiki perubahan pada jalur gerbang yang menyebabkan keterlambatan perjalanan.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pengawas jalur transportasi; belum mengetahui penyebab gangguan itu.
Last Updated Chapter: 0
Personality: Rasional, waspada, mengutamakan bukti dan prosedur.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Rasional, waspada, mengutamakan bukti dan prosedur.

**Tujuan pribadi:** Menyelidiki perubahan pada jalur gerbang yang menyebabkan keterlambatan perjalanan.

**Fakta terkonfirmasi:** Pengawas jalur transportasi; belum mengetahui penyebab gangguan itu.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.