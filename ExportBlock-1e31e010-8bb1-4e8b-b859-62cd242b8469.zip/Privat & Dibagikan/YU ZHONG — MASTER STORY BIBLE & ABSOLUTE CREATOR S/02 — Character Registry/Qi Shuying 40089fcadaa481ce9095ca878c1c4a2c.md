# Qi Shuying

Character ID: CHR-31
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Abadi Sejati
Cultivation Stage: Awal
Current Location: Kota Menara Rembulan
Faction: Paviliun Informasi Bayang
Goals: Membangun arsip rumor dengan penanda tingkat keandalan.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Kurator informasi; tidak menyamakan dugaan dengan bukti.
Last Updated Chapter: 0
Personality: Sangat berhati-hati, objektif, memisahkan fakta dari spekulasi.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Sangat berhati-hati, objektif, memisahkan fakta dari spekulasi.

**Tujuan pribadi:** Membangun arsip rumor dengan penanda tingkat keandalan.

**Fakta terkonfirmasi:** Kurator informasi; tidak menyamakan dugaan dengan bukti.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.