# Fang Yueshu

Character ID: CHR-26
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Pendirian Fondasi
Cultivation Stage: Menengah
Current Location: Kota Pasar Seribu Lampu
Faction: Dewan Penilai Artefak
Goals: Mencegah artefak palsu membahayakan pembeli.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pemeriksa artefak yang menyimpan bukti uji untuk setiap penilaian.
Last Updated Chapter: 0
Personality: Cermat, adil, tidak mudah terkesan oleh harga tinggi.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Cermat, adil, tidak mudah terkesan oleh harga tinggi.

**Tujuan pribadi:** Mencegah artefak palsu membahayakan pembeli.

**Fakta terkonfirmasi:** Pemeriksa artefak yang menyimpan bukti uji untuk setiap penilaian.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.