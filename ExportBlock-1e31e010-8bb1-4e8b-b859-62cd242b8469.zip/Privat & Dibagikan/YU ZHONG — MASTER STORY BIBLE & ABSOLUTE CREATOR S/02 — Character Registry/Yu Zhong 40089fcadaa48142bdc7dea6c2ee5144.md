# Yu Zhong

Character ID: CHR-1
Continuity Notes: Shared Base Profile hanya memuat fakta lintas timeline. Wajah utama/wujud asli Yu Zhong adalah versi surgawi tanpa topeng: wajah sangat tampan, simetris dan halus, kulit cerah, mata amber keemasan kemerahan, rambut hitam panjang dengan ornamen emas, jubah hitam-putih-emas dan aura kosmik keemasan. Penampilan bertopeng metalik adalah penyamaran, bukan wajah utama. Ranah, lokasi, usia, inventaris, hubungan, dan pengetahuan khusus timeline dicatat di state masing-masing. Pengguna mengendalikan semua tindakan, ucapan, pikiran, emosi, keputusan, dan penggunaan kekuatan Yu Zhong.
Cultivation Realm: Belum ditetapkan
Cultivation Stage: Belum diketahui
Current Location: Belum ditetapkan
Faction: Belum ditetapkan
Goals: Tidak ada misi wajib atau tujuan otomatis.
Knowledge of Yu Zhong Identity: Belum diketahui
Known Facts: Identitas sejati dan asal-usul belum ditetapkan; jangan gunakan konsep reinkarnasi atau kehidupan lampau. Identitas rahasia; Sistem Mutlak Sang Pencipta aktif sepenuhnya sejak awal. WAJAH UTAMA / WUJUD ASLI — ditetapkan pengguna pada 2026-10-23 berdasarkan visual referensi yang baru dibuat: wajah sangat tampan dengan proporsi halus dan simetris, kulit cerah, rahang rapi, hidung tegas, bibir terdefinisi, mata amber keemasan kemerahan yang tajam namun elegan; rambut hitam panjang mengalir dengan ornamen rambut emas; tanpa topeng. Gaya utama: jubah surgawi hitam, putih gading, dan emas dengan sulaman rumit, ornamen permata, rantai, serta aura cahaya keemasan kosmik. Ini adalah wajah/wujud utama Yu Zhong, bukan penyamaran bertopeng metalik. Gambar yang dihasilkan menjadi acuan visual deskriptif; file gambar belum dilampirkan langsung ke halaman Notion.
Last Updated Chapter: 0
Personality: Tidak dikunci secara sempit; pengguna menentukan respons, pikiran, emosi, dan tindakan.
Role: Protagonist
Status: Aktif
Timeline ID: SHARED-BASE
Timeline Scope: Shared Base Profile

Kanon karakter utama. Otoritas Mutlak terpisah dari ranah kultivasi. Pengguna memegang kendali penuh atas semua tindakan, ucapan, pikiran, emosi, niat, dan keputusan Yu Zhong.