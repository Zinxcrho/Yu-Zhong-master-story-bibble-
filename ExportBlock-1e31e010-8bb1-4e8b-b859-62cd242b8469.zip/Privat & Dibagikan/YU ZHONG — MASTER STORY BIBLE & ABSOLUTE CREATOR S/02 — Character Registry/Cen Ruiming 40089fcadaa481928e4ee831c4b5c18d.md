# Cen Ruiming

Character ID: CHR-22
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Laut Qi
Cultivation Stage: Akhir
Current Location: Lembah Angin Sunyi
Faction: Sekte Seribu Jimat
Goals: Membuat jimat komunikasi yang stabil di area dengan gangguan spiritual.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Perajin jimat; sebagian eksperimennya masih dalam tahap uji.
Last Updated Chapter: 0
Personality: Ceria, teliti, gemar menguji desain baru.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Ceria, teliti, gemar menguji desain baru.

**Tujuan pribadi:** Membuat jimat komunikasi yang stabil di area dengan gangguan spiritual.

**Fakta terkonfirmasi:** Perajin jimat; sebagian eksperimennya masih dalam tahap uji.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.