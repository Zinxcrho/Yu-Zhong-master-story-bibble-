# Yue Lanqing

Character ID: CHR-20
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Jiwa Baru Lahir
Cultivation Stage: Awal
Current Location: Dataran Salju Utara
Faction: Klan Rubah Salju
Goals: Menjaga jalur migrasi binatang roh agar tidak terganggu pemburu liar.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pelacak wilayah dingin yang mengenal kebiasaan binatang roh lokal.
Last Updated Chapter: 0
Personality: Lincah, cerdas, menyukai penyelesaian konflik tanpa kekerasan.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Lincah, cerdas, menyukai penyelesaian konflik tanpa kekerasan.

**Tujuan pribadi:** Menjaga jalur migrasi binatang roh agar tidak terganggu pemburu liar.

**Fakta terkonfirmasi:** Pelacak wilayah dingin yang mengenal kebiasaan binatang roh lokal.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.