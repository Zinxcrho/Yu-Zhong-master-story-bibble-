# Zhao Wenqi

Character ID: CHR-12
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Laut Qi
Cultivation Stage: Menengah
Current Location: Kota Pelabuhan Tujuh Ombak
Faction: Persekutuan Dagang Jalur Giok
Goals: Membuka rute dagang aman melalui kepulauan berkabut.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pedagang logistik yang mencatat kontrak dan biaya perjalanan.
Last Updated Chapter: 0
Personality: Supel, teliti pada angka, menghindari risiko yang tidak perlu.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Supel, teliti pada angka, menghindari risiko yang tidak perlu.

**Tujuan pribadi:** Membuka rute dagang aman melalui kepulauan berkabut.

**Fakta terkonfirmasi:** Pedagang logistik yang mencatat kontrak dan biaya perjalanan.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.