# Tang Moye

Character ID: CHR-18
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Dewa Raja
Cultivation Stage: Awal
Current Location: Dataran Cermin
Faction: Sekte Jiwa Cermin
Goals: Menguasai informasi tentang artefak cermin tanpa memicu perang terbuka.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pemain politik rahasia; motifnya tidak diketahui seluruh anggota sekte.
Last Updated Chapter: 0
Personality: Dingin, strategis, sangat menjaga rahasia organisasinya.
Role: Antagonist
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Dingin, strategis, sangat menjaga rahasia organisasinya.

**Tujuan pribadi:** Menguasai informasi tentang artefak cermin tanpa memicu perang terbuka.

**Fakta terkonfirmasi:** Pemain politik rahasia; motifnya tidak diketahui seluruh anggota sekte.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.