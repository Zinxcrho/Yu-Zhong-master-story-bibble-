# Xue Hantao

Character ID: CHR-10
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Abadi Sejati
Cultivation Stage: Menengah
Current Location: Dataran Salju Utara
Faction: Kerajaan Tembok Salju
Goals: Memperbaiki pos pengawas di jalur utara sebelum musim badai.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Komandan penjaga perbatasan; loyalitasnya pada tugas, bukan sekte tertentu.
Last Updated Chapter: 0
Personality: Tegas, hemat bicara, memprioritaskan keselamatan warga.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Tegas, hemat bicara, memprioritaskan keselamatan warga.

**Tujuan pribadi:** Memperbaiki pos pengawas di jalur utara sebelum musim badai.

**Fakta terkonfirmasi:** Komandan penjaga perbatasan; loyalitasnya pada tugas, bukan sekte tertentu.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.