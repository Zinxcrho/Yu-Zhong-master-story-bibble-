# Gu Shanyue

Character ID: CHR-11
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Pendirian Fondasi
Cultivation Stage: Awal
Current Location: Kota Pasar Seribu Lampu
Faction: Rumah Lelang Tiga Lentera
Goals: Membangun standar autentikasi artefak yang lebih transparan.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Penilai barang lelang; menolak menjamin artefak yang belum diperiksa.
Last Updated Chapter: 0
Personality: Pandai membaca suasana, berhati-hati dalam transaksi.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Pandai membaca suasana, berhati-hati dalam transaksi.

**Tujuan pribadi:** Membangun standar autentikasi artefak yang lebih transparan.

**Fakta terkonfirmasi:** Penilai barang lelang; menolak menjamin artefak yang belum diperiksa.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.