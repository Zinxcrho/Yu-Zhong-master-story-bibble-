# Lin Beichen

Character ID: CHR-13
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Kaisar Abadi
Cultivation Stage: Akhir
Current Location: Dataran Teratai
Faction: Sekte Teratai Sembilan Cakra
Goals: Menjaga netralitas sektenya dalam perebutan jalur ramuan.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Tetua senior; tidak akan ikut campur tanpa alasan yang jelas.
Last Updated Chapter: 0
Personality: Berwibawa, keras pada disiplin, menghormati bukti.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Berwibawa, keras pada disiplin, menghormati bukti.

**Tujuan pribadi:** Menjaga netralitas sektenya dalam perebutan jalur ramuan.

**Fakta terkonfirmasi:** Tetua senior; tidak akan ikut campur tanpa alasan yang jelas.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.