# Zhu Tianhe

Character ID: CHR-21
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Abadi Sejati
Cultivation Stage: Akhir
Current Location: Lautan Awan Purba
Faction: Armada Pengelana Bintang
Goals: Memastikan jalur navigasi antarpulau tetap dapat digunakan.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Kapten ekspedisi; tidak mengklaim telah menembus wilayah yang belum dipetakan.
Last Updated Chapter: 0
Personality: Berani, mandiri, selalu menghitung risiko perjalanan.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Berani, mandiri, selalu menghitung risiko perjalanan.

**Tujuan pribadi:** Memastikan jalur navigasi antarpulau tetap dapat digunakan.

**Fakta terkonfirmasi:** Kapten ekspedisi; tidak mengklaim telah menembus wilayah yang belum dipetakan.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.