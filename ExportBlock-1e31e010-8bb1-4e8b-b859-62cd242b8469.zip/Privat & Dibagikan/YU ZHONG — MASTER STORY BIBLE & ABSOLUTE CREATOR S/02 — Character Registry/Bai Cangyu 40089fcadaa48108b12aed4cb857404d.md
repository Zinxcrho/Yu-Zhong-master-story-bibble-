# Bai Cangyu

Character ID: CHR-4
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Laut Qi
Cultivation Stage: Akhir
Current Location: Kawasan Rasi Selatan
Faction: Klan Mata Perak
Goals: Memetakan perubahan jalur bintang di wilayah selatan.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Penjelajah peta langit; semua temuannya perlu diverifikasi.
Last Updated Chapter: 0
Personality: Pendiam, observatif, lebih percaya bukti daripada firasat.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Pendiam, observatif, lebih percaya bukti daripada firasat.

**Tujuan pribadi:** Memetakan perubahan jalur bintang di wilayah selatan.

**Fakta terkonfirmasi:** Penjelajah peta langit; semua temuannya perlu diverifikasi.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.