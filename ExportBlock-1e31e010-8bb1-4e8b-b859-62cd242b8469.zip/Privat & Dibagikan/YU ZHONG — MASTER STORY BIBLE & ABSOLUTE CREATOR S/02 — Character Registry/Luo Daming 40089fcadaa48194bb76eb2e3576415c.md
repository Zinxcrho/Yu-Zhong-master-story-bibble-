# Luo Daming

Adult Status: Adult 18+ Confirmed
Age: 41
Behavioral Patterns: Menjelaskan rute dan bayaran jika ditanya; akan menawar atau menolak bila syarat calon pengawal tidak sesuai.
Character ID: CHR-34
Continuity Notes: Karakter tetap ada sebagai entitas dunia Sandbox, tetapi adegan pembuka Kota Qinghe telah disisihkan sebagai arsip dan bukan alur aktif. Jangan menganggap Luo Daming sedang berinteraksi dengan Yu Zhong atau mengetahui perkembangan terbaru tanpa jalur informasi/adegan yang dikonfirmasi.
Core Motivations: Menemukan pengawal yang dapat diandalkan dengan syarat dan bayaran yang disepakati jelas.
Cultivation Realm: Belum diketahui
Cultivation Stage: Belum diketahui
Current Location: Kota Qinghe — lokasi terakhir tercatat dalam arsip SBX-001; keberadaan saat ini belum dikonfirmasi.
Current Occupation: Broker dan perekrut pengawal karavan independen
Employment Status: Self-employed
Faction: Kafilah independen
Fears and Vulnerabilities: Kerugian kargo, keterlambatan, dan pengawal yang meninggalkan tugas di tengah perjalanan.
Goals: Merekrut dua pengawal sebelum karavan berangkat.
Information Access: Mengetahui kondisi karavannya sendiri, rencana perjalanan, dan informasi dagang yang ia peroleh; tidak mengetahui identitas Yu Zhong tanpa sumber.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pada awal SBX-001, ia sedang mencari dua pengawal untuk perjalanan karavan menuju Desa Buluh.
Last Updated Chapter: 1
Personality: Pandai bernegosiasi, berhati-hati soal uang, tegas tentang tanggung jawab, dan tidak langsung percaya pada penampilan atau klaim seseorang.
Relationship Dynamics: Belum memiliki hubungan atau penilaian pribadi yang mapan terhadap Yu Zhong.
Role: NPC
Status: Aktif
Timeline ID: SBX-001
Timeline Scope: Sandbox Variant
Values and Boundaries: Menghendaki tanggung jawab yang jelas; tidak menganggap tawaran lisan sebagai kontrak final sebelum syarat disepakati.
Voice and Dialogue Style: Suara lantang ketika merekrut, lalu berbicara langsung dan rinci saat membahas kontrak.
Work Reputation: Neutral

NPC Sandbox-only. Penawaran kerja tidak berarti Yu Zhong telah melamar atau diterima.