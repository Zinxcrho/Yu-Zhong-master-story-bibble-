# Huo Zhenyu

Character ID: CHR-19
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Inti Emas
Cultivation Stage: Akhir
Current Location: Kota Bara Biru
Faction: Perhimpunan Pandai Besi Bara Biru
Goals: Mengembangkan paduan logam yang lebih tahan terhadap korosi Qi.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Pandai besi senior; tidak menjual senjata sebagai artefak kuno tanpa bukti.
Last Updated Chapter: 0
Personality: Blak-blakan, telaten, bangga pada mutu hasil kerja.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Blak-blakan, telaten, bangga pada mutu hasil kerja.

**Tujuan pribadi:** Mengembangkan paduan logam yang lebih tahan terhadap korosi Qi.

**Fakta terkonfirmasi:** Pandai besi senior; tidak menjual senjata sebagai artefak kuno tanpa bukti.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.