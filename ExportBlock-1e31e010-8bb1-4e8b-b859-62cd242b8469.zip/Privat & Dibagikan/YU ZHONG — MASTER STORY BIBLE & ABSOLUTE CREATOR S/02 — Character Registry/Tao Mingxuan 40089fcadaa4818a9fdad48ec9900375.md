# Tao Mingxuan

Character ID: CHR-27
Continuity Notes: Profil dasar dunia bersama. Belum otomatis bertemu Yu Zhong atau menjadi bagian dari misi utama. Jangan ubah pengetahuan atau hubungan tanpa kejadian yang benar-benar terjadi.
Cultivation Realm: Abadi Emas
Cultivation Stage: Menengah
Current Location: Lembah Fajar Terakhir
Faction: Kerajaan Lembah Gema
Goals: Mengumpulkan cerita rakyat dan memisahkan fakta sejarah dari legenda.
Knowledge of Yu Zhong Identity: Tidak tahu
Known Facts: Sejarawan lapangan; selalu menandai hal yang belum terverifikasi.
Last Updated Chapter: 0
Personality: Penuh rasa ingin tahu, sabar, suka mendengarkan saksi.
Role: NPC
Status: Aktif
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Penuh rasa ingin tahu, sabar, suka mendengarkan saksi.

**Tujuan pribadi:** Mengumpulkan cerita rakyat dan memisahkan fakta sejarah dari legenda.

**Fakta terkonfirmasi:** Sejarawan lapangan; selalu menandai hal yang belum terverifikasi.

**Batas kontinuitas:** Karakter ini belum mengetahui identitas sejati Yu Zhong dan belum terhubung otomatis dengan alur utama atau Sandbox.