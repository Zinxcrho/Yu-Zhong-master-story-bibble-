# Kota Teratai Emas

Category: Lokasi
Counted in 838: No
History: Mewarisi tradisi lama yang beberapa bagiannya masih diperdebatkan.
Last Updated Chapter: 0
Leader: Tidak berlaku
Notes: Lokasi tambahan di luar hitungan 838 organisasi. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Akses dan pengaruh bergantung pada kondisi wilayah serta izin yang berlaku.
Power Base and Resources: Kota kanal dengan pasar rempah, kain, dan bahan alkimia. Sumber daya utama: sarana penginapan dan perdagangan.
Registry ID: ORG-877
Status: Aktif
Territory or Location: Dataran Teratai
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Kota kanal dengan pasar rempah, kain, dan bahan alkimia.

**Kawasan:** Dataran Teratai.

**Sumber daya atau fungsi:** sarana penginapan dan perdagangan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.