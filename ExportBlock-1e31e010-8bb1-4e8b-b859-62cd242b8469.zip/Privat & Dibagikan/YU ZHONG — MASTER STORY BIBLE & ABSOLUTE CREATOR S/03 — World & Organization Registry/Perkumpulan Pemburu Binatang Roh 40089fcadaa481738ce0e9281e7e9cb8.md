# Perkumpulan Pemburu Binatang Roh

Category: Kelompok Independen
Counted in 838: No
History: Dibentuk untuk memenuhi kebutuhan bersama setelah sengketa lokal.
Last Updated Chapter: 0
Leader: Pengelola Bai Qing
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menetapkan aturan berburu untuk mencegah kerusakan habitat. Sumber daya utama: bengkel, gudang, dan tenaga ahli.
Registry ID: ORG-864
Status: Aktif
Territory or Location: Hutan Binatang Roh
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menetapkan aturan berburu untuk mencegah kerusakan habitat.

**Kawasan:** Hutan Binatang Roh.

**Sumber daya atau fungsi:** bengkel, gudang, dan tenaga ahli.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.