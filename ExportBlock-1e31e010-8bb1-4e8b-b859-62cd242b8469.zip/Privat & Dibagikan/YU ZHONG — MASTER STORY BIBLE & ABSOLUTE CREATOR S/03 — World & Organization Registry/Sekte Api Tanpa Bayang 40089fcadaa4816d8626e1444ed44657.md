# Sekte Api Tanpa Bayang

Category: Sekte Besar
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Patriark Agung Tang Yue
Notes: Entitas ke-7 dari 20 sekte besar kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan khusus yang dapat dikembangkan: Sekte Kabut Awan Senja dan Sekte Penjaga Nadi Langit; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-70
Status: Aktif
Territory or Location: Kepulauan Kabut
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-7 dari 20 sekte besar kanonis.

**Kawasan:** Kepulauan Kabut.

**Watak kekuatan:** Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka.

**Sumber daya:** ladang pangan, kanal, dan jaringan logistik.

**Sejarah:** Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.

**Relasi:** Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.