# Kekaisaran Mahkota Awan

Category: Kekaisaran
Counted in 838: Yes
History: Sejarah lisannya mengenang seorang pengelana yang mengajarkan metode bertahan hidup, bukan teknik terlarang.
Last Updated Chapter: 0
Leader: Kaisar Feng Zhen
Notes: Entitas ke-6 dari 20 kekaisaran kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan khusus yang dapat dikembangkan: Kerajaan Embun Abadi dan Kekaisaran Gunung Cakrawala; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Ekonominya bergantung pada perdagangan dan perjanjian, sehingga konflik berkepanjangan akan merugikan mereka. Sumber daya utama: pelabuhan sungai, kapal dagang, dan gudang bahan spiritual.
Registry ID: ORG-6
Status: Aktif
Territory or Location: Rawa Bintang
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-6 dari 20 kekaisaran kanonis.

**Kawasan:** Rawa Bintang.

**Watak kekuatan:** Ekonominya bergantung pada perdagangan dan perjanjian, sehingga konflik berkepanjangan akan merugikan mereka.

**Sumber daya:** pelabuhan sungai, kapal dagang, dan gudang bahan spiritual.

**Sejarah:** Sejarah lisannya mengenang seorang pengelana yang mengajarkan metode bertahan hidup, bukan teknik terlarang.

**Relasi:** Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.