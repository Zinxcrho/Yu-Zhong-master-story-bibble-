# Kerajaan Bintang Jatuh

Category: Kerajaan
Counted in 838: Yes
History: Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.
Last Updated Chapter: 0
Leader: Raja Kong Zhen
Notes: Entitas ke-29 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan khusus yang dapat dikembangkan: Sekte Pedang Awan Senja dan Kerajaan Awan Retak; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman. Sumber daya utama: tambang kristal, batu formasi, dan laboratorium riset.
Registry ID: ORG-49
Status: Aktif
Territory or Location: Perbatasan Tiga Gerbang
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-29 dari 43 kerajaan kanonis.

**Kawasan:** Perbatasan Tiga Gerbang.

**Watak kekuatan:** Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman.

**Sumber daya:** tambang kristal, batu formasi, dan laboratorium riset.

**Sejarah:** Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.

**Relasi:** Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.