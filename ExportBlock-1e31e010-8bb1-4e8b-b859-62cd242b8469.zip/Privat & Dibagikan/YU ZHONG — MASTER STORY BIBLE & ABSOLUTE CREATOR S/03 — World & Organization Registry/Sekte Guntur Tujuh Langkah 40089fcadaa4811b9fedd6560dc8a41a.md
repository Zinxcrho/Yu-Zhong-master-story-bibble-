# Sekte Guntur Tujuh Langkah

Category: Sekte Besar
Counted in 838: Yes
History: Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.
Last Updated Chapter: 0
Leader: Patriark Agung Yue Yue
Notes: Entitas ke-16 dari 20 sekte besar kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan khusus yang dapat dikembangkan: Sekte Kura-Kura Embun Giok dan Sekte Phoenix Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman. Sumber daya utama: tambang kristal, batu formasi, dan laboratorium riset.
Registry ID: ORG-79
Status: Aktif
Territory or Location: Perbatasan Tiga Gerbang
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-16 dari 20 sekte besar kanonis.

**Kawasan:** Perbatasan Tiga Gerbang.

**Watak kekuatan:** Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman.

**Sumber daya:** tambang kristal, batu formasi, dan laboratorium riset.

**Sejarah:** Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.

**Relasi:** Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.