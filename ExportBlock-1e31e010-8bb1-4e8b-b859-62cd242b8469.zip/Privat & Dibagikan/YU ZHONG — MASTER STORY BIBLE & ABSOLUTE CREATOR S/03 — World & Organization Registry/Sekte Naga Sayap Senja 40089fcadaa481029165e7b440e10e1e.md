# Sekte Naga Sayap Senja

Category: Sekte Kecil
Counted in 838: Yes
History: Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.
Last Updated Chapter: 0
Leader: Kepala Sekte Gu He
Notes: Entitas ke-726 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan yang dapat dikembangkan: Kekaisaran Seribu Lentera dan Sekte Cermin Sayap Senja; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman. Sumber daya utama: tambang kristal, batu formasi, dan laboratorium riset.
Registry ID: ORG-809
Status: Aktif
Territory or Location: Lautan Awan Purba
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile