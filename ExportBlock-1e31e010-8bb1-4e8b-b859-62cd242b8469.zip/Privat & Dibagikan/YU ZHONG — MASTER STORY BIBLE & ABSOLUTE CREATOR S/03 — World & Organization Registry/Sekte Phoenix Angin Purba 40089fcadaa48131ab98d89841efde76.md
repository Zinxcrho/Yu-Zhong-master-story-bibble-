# Sekte Phoenix Angin Purba

Category: Sekte Kecil
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Kepala Sekte Yun Xuan
Notes: Entitas ke-184 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Memiliki persaingan lama terkait sumber daya, tetapi kedua pihak masih mematuhi perjanjian perbatasan. Hubungan yang dapat dikembangkan: Sekte Bintang Ombak Hitam dan Sekte Bulan Angin Purba; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-267
Status: Aktif
Territory or Location: Lembah Sungai Langit
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile