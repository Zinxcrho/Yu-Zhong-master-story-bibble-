# Sekte Gunung Rasi Utara

Category: Sekte Kecil
Counted in 838: Yes
History: Didirikan setelah beberapa klan perintis menyatukan wilayah yang terpecah oleh perang perbatasan.
Last Updated Chapter: 0
Leader: Kepala Sekte Luo Ming
Notes: Entitas ke-518 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan yang dapat dikembangkan: Sekte Rusa Badai Jingga dan Sekte Bangau Gerimis Roh; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pertahanan wilayah dan disiplin formasi menjadi keunggulan utama; kekuatan lapangan bergantung pada sumber daya setempat. Sumber daya utama: urat bijih spiritual, tambang giok, dan jalur kafilah.
Registry ID: ORG-601
Status: Aktif
Territory or Location: Hutan Seribu Akar
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile