# Sekte Kabut Pasir Surgawi

Category: Sekte Kecil
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Kepala Sekte Bai Tao
Notes: Entitas ke-324 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan yang dapat dikembangkan: Sekte Serigala Bayang Timur dan Sekte Kupu-Kupu Hujan Kristal; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-407
Status: Aktif
Territory or Location: Lereng Bintang Jatuh
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile