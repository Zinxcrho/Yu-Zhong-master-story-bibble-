# Paviliun Seribu Ramuan

Category: Perdagangan
Counted in 838: No
History: Dibentuk untuk memenuhi kebutuhan bersama setelah sengketa lokal.
Last Updated Chapter: 0
Leader: Pengelola Bai Yue
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Memperdagangkan ramuan dengan sistem pemeriksaan kualitas berlapis. Sumber daya utama: formasi pertahanan dan pengawas wilayah.
Registry ID: ORG-854
Status: Aktif
Territory or Location: Hutan Seribu Akar
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Memperdagangkan ramuan dengan sistem pemeriksaan kualitas berlapis.

**Kawasan:** Hutan Seribu Akar.

**Sumber daya atau fungsi:** formasi pertahanan dan pengawas wilayah.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.