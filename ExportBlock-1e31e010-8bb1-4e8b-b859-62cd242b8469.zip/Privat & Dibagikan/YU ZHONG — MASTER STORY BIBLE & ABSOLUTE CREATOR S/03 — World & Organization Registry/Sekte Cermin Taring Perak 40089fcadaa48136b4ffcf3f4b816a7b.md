# Sekte Cermin Taring Perak

Category: Sekte Kecil
Counted in 838: Yes
History: Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.
Last Updated Chapter: 0
Leader: Kepala Sekte Jin Lin
Notes: Entitas ke-689 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Sekte Naga Sayap Senja dan Sekte Teratai Nadi Bumi; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu. Sumber daya utama: ladang ramuan obat, kebun roh, dan ahli alkimia.
Registry ID: ORG-772
Status: Aktif
Territory or Location: Dataran Arunika
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile