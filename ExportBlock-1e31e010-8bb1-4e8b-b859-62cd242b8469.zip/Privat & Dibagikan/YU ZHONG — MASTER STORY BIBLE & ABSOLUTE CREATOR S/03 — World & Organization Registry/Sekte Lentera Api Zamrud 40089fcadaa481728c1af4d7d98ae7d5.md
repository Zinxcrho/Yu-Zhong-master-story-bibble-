# Sekte Lentera Api Zamrud

Category: Sekte Kecil
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Kepala Sekte He Shuo
Notes: Entitas ke-500 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan yang dapat dikembangkan: Sekte Kupu-Kupu Gerimis Roh dan Sekte Lonceng Rasi Utara; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-583
Status: Aktif
Territory or Location: Kawasan Menara Tua
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile