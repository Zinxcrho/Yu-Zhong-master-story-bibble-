# Sekte Telapak Gunung Kosong

Category: Sekte Besar
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Patriark Agung Ren Yue
Notes: Entitas ke-10 dari 20 sekte besar kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan khusus yang dapat dikembangkan: Sekte Teratai Embun Giok dan Sekte Pedang Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-73
Status: Aktif
Territory or Location: Kawasan Menara Tua
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-10 dari 20 sekte besar kanonis.

**Kawasan:** Kawasan Menara Tua.

**Watak kekuatan:** Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan.

**Sumber daya:** mata air Qi pekat serta gua meditasi alami.

**Sejarah:** Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.

**Relasi:** Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.