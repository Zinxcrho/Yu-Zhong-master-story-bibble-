# Sekte Serigala Bintang Retak

Category: Sekte Kecil
Counted in 838: Yes
History: Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.
Last Updated Chapter: 0
Leader: Kepala Sekte Heng Rong
Notes: Entitas ke-111 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan yang dapat dikembangkan: Sekte Akar Rembulan Pucat dan Sekte Kabut Bintang Retak; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi. Sumber daya utama: perpustakaan teknik, prasasti leluhur, dan arsip silsilah.
Registry ID: ORG-194
Status: Aktif
Territory or Location: Gurun Kaca Merah
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile