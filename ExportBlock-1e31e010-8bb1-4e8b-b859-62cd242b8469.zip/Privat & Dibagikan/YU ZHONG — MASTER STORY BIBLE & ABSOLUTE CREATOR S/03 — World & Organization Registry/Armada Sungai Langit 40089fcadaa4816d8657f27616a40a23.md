# Armada Sungai Langit

Category: Perdagangan
Counted in 838: No
History: Memiliki piagam pendirian yang menekankan netralitas dan pencatatan transaksi.
Last Updated Chapter: 0
Leader: Pengelola Qin Yue
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Mengangkut barang lintas wilayah melalui kapal yang dilindungi formasi. Sumber daya utama: jaringan kurir dan informasi terverifikasi.
Registry ID: ORG-851
Status: Aktif
Territory or Location: Lembah Sungai Langit
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Mengangkut barang lintas wilayah melalui kapal yang dilindungi formasi.

**Kawasan:** Lembah Sungai Langit.

**Sumber daya atau fungsi:** jaringan kurir dan informasi terverifikasi.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.