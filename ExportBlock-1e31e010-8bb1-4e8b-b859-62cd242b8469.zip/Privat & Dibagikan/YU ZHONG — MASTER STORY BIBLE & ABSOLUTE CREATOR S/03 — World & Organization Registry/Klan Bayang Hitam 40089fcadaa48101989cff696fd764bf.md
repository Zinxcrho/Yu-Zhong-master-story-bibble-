# Klan Bayang Hitam

Category: Keluarga atau Klan
Counted in 838: No
History: Berkembang secara bertahap dari komunitas kecil dan jaringan kepercayaan.
Last Updated Chapter: 0
Leader: Pengelola Xue Rong
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Mengandalkan pengintaian dan jaringan kurir, bukan kekuatan militer besar. Sumber daya utama: sarana penginapan dan perdagangan.
Registry ID: ORG-845
Status: Aktif
Territory or Location: Jurang Senja
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Mengandalkan pengintaian dan jaringan kurir, bukan kekuatan militer besar.

**Kawasan:** Jurang Senja.

**Sumber daya atau fungsi:** sarana penginapan dan perdagangan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.