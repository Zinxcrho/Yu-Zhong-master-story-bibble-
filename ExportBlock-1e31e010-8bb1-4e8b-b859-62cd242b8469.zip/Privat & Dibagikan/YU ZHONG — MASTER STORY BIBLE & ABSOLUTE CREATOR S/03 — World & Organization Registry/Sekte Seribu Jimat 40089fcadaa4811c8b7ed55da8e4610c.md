# Sekte Seribu Jimat

Category: Sekte Besar
Counted in 838: Yes
History: Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.
Last Updated Chapter: 0
Leader: Patriark Agung Jin Yue
Notes: Entitas ke-9 dari 20 sekte besar kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh. Hubungan khusus yang dapat dikembangkan: Sekte Naga Embun Giok dan Sekte Teratai Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu. Sumber daya utama: ladang ramuan obat, kebun roh, dan ahli alkimia.
Registry ID: ORG-72
Status: Aktif
Territory or Location: Lembah Angin Sunyi
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-9 dari 20 sekte besar kanonis.

**Kawasan:** Lembah Angin Sunyi.

**Watak kekuatan:** Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu.

**Sumber daya:** ladang ramuan obat, kebun roh, dan ahli alkimia.

**Sejarah:** Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.

**Relasi:** Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.