# Sekte Macan Petir Sunyi

Category: Sekte Kecil
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Kepala Sekte Qi Bo
Notes: Entitas ke-257 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Sekte Bambu Salju Arunika dan Sekte Batu Petir Sunyi; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-340
Status: Aktif
Territory or Location: Kepulauan Kabut
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile