# Sekte Kabut Hujan Kristal

Category: Sekte Kecil
Counted in 838: Yes
History: Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.
Last Updated Chapter: 0
Leader: Kepala Sekte Song Tao
Notes: Entitas ke-349 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh. Hubungan yang dapat dikembangkan: Sekte Serigala Cahaya Lembayung dan Sekte Kupu-Kupu Bayang Timur; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu. Sumber daya utama: ladang ramuan obat, kebun roh, dan ahli alkimia.
Registry ID: ORG-432
Status: Aktif
Territory or Location: Lembah Angin Sunyi
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile