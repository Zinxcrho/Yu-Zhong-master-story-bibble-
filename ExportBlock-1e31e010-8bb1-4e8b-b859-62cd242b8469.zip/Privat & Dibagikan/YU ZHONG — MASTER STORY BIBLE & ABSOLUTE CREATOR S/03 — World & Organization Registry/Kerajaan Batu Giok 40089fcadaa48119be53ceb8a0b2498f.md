# Kerajaan Batu Giok

Category: Kerajaan
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Raja Mu Yue
Notes: Entitas ke-33 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan khusus yang dapat dikembangkan: Sekte Macan Awan Senja dan Sekte Menara Bintang Purba; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-53
Status: Aktif
Territory or Location: Dataran Salju Utara
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-33 dari 43 kerajaan kanonis.

**Kawasan:** Dataran Salju Utara.

**Watak kekuatan:** Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan.

**Sumber daya:** mata air Qi pekat serta gua meditasi alami.

**Sejarah:** Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.

**Relasi:** Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.