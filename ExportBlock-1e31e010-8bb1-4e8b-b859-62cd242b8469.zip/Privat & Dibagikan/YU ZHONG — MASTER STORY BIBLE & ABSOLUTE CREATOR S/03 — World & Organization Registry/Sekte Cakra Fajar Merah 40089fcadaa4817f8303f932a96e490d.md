# Sekte Cakra Fajar Merah

Category: Sekte Kecil
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Kepala Sekte Ming Kai
Notes: Entitas ke-154 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan yang dapat dikembangkan: Sekte Gerbang Angin Purba dan Sekte Sungai Fajar Merah; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-237
Status: Aktif
Territory or Location: Lembah Sungai Langit
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile