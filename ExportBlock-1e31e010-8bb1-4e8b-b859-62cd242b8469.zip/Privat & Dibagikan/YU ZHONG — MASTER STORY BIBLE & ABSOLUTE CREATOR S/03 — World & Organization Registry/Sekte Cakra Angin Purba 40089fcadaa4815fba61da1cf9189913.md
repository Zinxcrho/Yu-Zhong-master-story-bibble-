# Sekte Cakra Angin Purba

Category: Sekte Kecil
Counted in 838: Yes
History: Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.
Last Updated Chapter: 0
Leader: Kepala Sekte Wei Xuan
Notes: Entitas ke-179 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan yang dapat dikembangkan: Sekte Gerbang Ombak Hitam dan Sekte Sungai Angin Purba; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu. Sumber daya utama: ladang ramuan obat, kebun roh, dan ahli alkimia.
Registry ID: ORG-262
Status: Aktif
Territory or Location: Dataran Arunika
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile