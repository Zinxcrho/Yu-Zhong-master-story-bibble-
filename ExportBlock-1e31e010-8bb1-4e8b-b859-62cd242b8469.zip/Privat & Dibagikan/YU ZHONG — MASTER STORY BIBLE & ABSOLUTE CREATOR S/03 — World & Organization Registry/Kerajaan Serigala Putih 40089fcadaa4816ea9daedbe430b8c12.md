# Kerajaan Serigala Putih

Category: Kerajaan
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Raja Ming Zhen
Notes: Entitas ke-17 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan khusus yang dapat dikembangkan: Sekte Alkimia Embun Emas dan Kerajaan Tembok Salju; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-37
Status: Aktif
Territory or Location: Lembah Bara Biru
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-17 dari 43 kerajaan kanonis.

**Kawasan:** Lembah Bara Biru.

**Watak kekuatan:** Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa.

**Sumber daya:** hutan binatang roh, bahan kulit, tulang, dan inti monster.

**Sejarah:** Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.

**Relasi:** Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.