# Sekte Bulan Petir Sunyi

Category: Sekte Kecil
Counted in 838: Yes
History: Wilayahnya pernah dilanda bencana spiritual; tata pemerintahan dan pertahanannya dibangun ulang sesudahnya.
Last Updated Chapter: 0
Leader: Kepala Sekte Yan Ling
Notes: Entitas ke-272 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Memiliki persaingan lama terkait sumber daya, tetapi kedua pihak masih mematuhi perjanjian perbatasan. Hubungan yang dapat dikembangkan: Sekte Phoenix Pasir Surgawi dan Sekte Qilin Salju Arunika; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Jaringan informasi dan penguasaan jalur perjalanan memberinya pengaruh melebihi ukuran wilayahnya. Sumber daya utama: pasar artefak, bengkel pandai besi, dan pengrajin jimat.
Registry ID: ORG-355
Status: Aktif
Territory or Location: Gurun Zamrud
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile