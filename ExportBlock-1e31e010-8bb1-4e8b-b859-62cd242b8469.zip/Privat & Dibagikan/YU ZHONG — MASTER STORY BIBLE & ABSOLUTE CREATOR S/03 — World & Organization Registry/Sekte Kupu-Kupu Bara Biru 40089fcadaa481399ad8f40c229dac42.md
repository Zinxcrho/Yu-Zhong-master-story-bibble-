# Sekte Kupu-Kupu Bara Biru

Category: Sekte Kecil
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Kepala Sekte Tang Rong
Notes: Entitas ke-87 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan yang dapat dikembangkan: Sekte Kabut Bintang Retak dan Sekte Lentera Bara Biru; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-170
Status: Aktif
Territory or Location: Kawasan Rasi Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile