# Sekte Akar Petir Sunyi

Category: Sekte Kecil
Counted in 838: Yes
History: Sejarah lisannya mengenang seorang pengelana yang mengajarkan metode bertahan hidup, bukan teknik terlarang.
Last Updated Chapter: 0
Leader: Kepala Sekte Feng Ling
Notes: Entitas ke-273 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Sekte Qilin Pasir Surgawi dan Sekte Serigala Salju Arunika; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Ekonominya bergantung pada perdagangan dan perjanjian, sehingga konflik berkepanjangan akan merugikan mereka. Sumber daya utama: pelabuhan sungai, kapal dagang, dan gudang bahan spiritual.
Registry ID: ORG-356
Status: Aktif
Territory or Location: Teluk Naga Kabut
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile