# Bank Roh Menara Utara

Category: Perdagangan
Counted in 838: No
History: Berkembang secara bertahap dari komunitas kecil dan jaringan kepercayaan.
Last Updated Chapter: 0
Leader: Pengelola Xue Yue
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menyimpan surat utang, kontrak, dan deposito batu spiritual. Sumber daya utama: arsip peta dan catatan perjalanan.
Registry ID: ORG-855
Status: Aktif
Territory or Location: Dataran Salju Utara
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menyimpan surat utang, kontrak, dan deposito batu spiritual.

**Kawasan:** Dataran Salju Utara.

**Sumber daya atau fungsi:** arsip peta dan catatan perjalanan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.