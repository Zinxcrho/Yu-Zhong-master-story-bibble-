# Sekte Phoenix Rembulan Pucat

Category: Sekte Kecil
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Kepala Sekte Yun Kai
Notes: Entitas ke-134 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan yang dapat dikembangkan: Sekte Bintang Fajar Merah dan Sekte Bulan Rembulan Pucat; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-217
Status: Aktif
Territory or Location: Lembah Bara Biru
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile