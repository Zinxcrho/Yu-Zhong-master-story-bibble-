# Klan Pedang Tujuh Fajar

Category: Keluarga atau Klan
Counted in 838: No
History: Dibentuk untuk memenuhi kebutuhan bersama setelah sengketa lokal.
Last Updated Chapter: 0
Leader: Pengelola Shen Rong
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Mengkhususkan diri pada teknik pedang berpasangan dan sumpah keluarga. Sumber daya utama: arsip peta dan catatan perjalanan.
Registry ID: ORG-839
Status: Aktif
Territory or Location: Dataran Arunika
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Mengkhususkan diri pada teknik pedang berpasangan dan sumpah keluarga.

**Kawasan:** Dataran Arunika.

**Sumber daya atau fungsi:** arsip peta dan catatan perjalanan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.