# Klan Seribu Daun

Category: Keluarga atau Klan
Counted in 838: No
History: Memiliki piagam pendirian yang menekankan netralitas dan pencatatan transaksi.
Last Updated Chapter: 0
Leader: Pengelola Qin Rong
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menjaga kebun ramuan langka dan memiliki aturan ketat soal panen. Sumber daya utama: jalur logistik dan kontrak perlindungan.
Registry ID: ORG-841
Status: Aktif
Territory or Location: Hutan Seribu Akar
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menjaga kebun ramuan langka dan memiliki aturan ketat soal panen.

**Kawasan:** Hutan Seribu Akar.

**Sumber daya atau fungsi:** jalur logistik dan kontrak perlindungan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.