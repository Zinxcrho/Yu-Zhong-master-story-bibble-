# Sekte Bulan Rasi Utara

Category: Sekte Kecil
Counted in 838: Yes
History: Wilayahnya pernah dilanda bencana spiritual; tata pemerintahan dan pertahanannya dibangun ulang sesudahnya.
Last Updated Chapter: 0
Leader: Kepala Sekte Yan Ming
Notes: Entitas ke-522 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan yang dapat dikembangkan: Sekte Phoenix Badai Jingga dan Sekte Qilin Gerimis Roh; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Jaringan informasi dan penguasaan jalur perjalanan memberinya pengaruh melebihi ukuran wilayahnya. Sumber daya utama: pasar artefak, bengkel pandai besi, dan pengrajin jimat.
Registry ID: ORG-605
Status: Aktif
Territory or Location: Pegunungan Pualam
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile