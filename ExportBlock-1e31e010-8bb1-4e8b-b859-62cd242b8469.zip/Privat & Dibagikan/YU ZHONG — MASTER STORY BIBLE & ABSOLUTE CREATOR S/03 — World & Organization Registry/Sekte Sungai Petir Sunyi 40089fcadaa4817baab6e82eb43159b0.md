# Sekte Sungai Petir Sunyi

Category: Sekte Kecil
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Kepala Sekte Tian Bo
Notes: Entitas ke-267 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan yang dapat dikembangkan: Sekte Cakra Pasir Surgawi dan Sekte Rusa Salju Arunika; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-350
Status: Aktif
Territory or Location: Kawasan Rasi Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile