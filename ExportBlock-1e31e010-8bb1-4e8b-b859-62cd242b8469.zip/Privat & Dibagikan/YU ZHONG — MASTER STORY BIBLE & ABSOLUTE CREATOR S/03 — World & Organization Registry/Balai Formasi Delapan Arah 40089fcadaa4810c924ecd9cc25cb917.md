# Balai Formasi Delapan Arah

Category: Asosiasi
Counted in 838: No
History: Dibentuk untuk memenuhi kebutuhan bersama setelah sengketa lokal.
Last Updated Chapter: 0
Leader: Pengelola Shen Qing
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menyimpan rancangan formasi dan mengesahkan kontrak pemasangan. Sumber daya utama: jaringan kurir dan informasi terverifikasi.
Registry ID: ORG-859
Status: Aktif
Territory or Location: Perbatasan Tiga Gerbang
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menyimpan rancangan formasi dan mengesahkan kontrak pemasangan.

**Kawasan:** Perbatasan Tiga Gerbang.

**Sumber daya atau fungsi:** jaringan kurir dan informasi terverifikasi.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.