# Kekaisaran Gurun Zamrud

Category: Kekaisaran
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Kaisar Yun Zhen
Notes: Entitas ke-17 dari 20 kekaisaran kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan khusus yang dapat dikembangkan: Kerajaan Ombak Jingga dan Kerajaan Bunga Es; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-17
Status: Aktif
Territory or Location: Lereng Bintang Jatuh
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-17 dari 20 kekaisaran kanonis.

**Kawasan:** Lereng Bintang Jatuh.

**Watak kekuatan:** Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa.

**Sumber daya:** hutan binatang roh, bahan kulit, tulang, dan inti monster.

**Sejarah:** Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.

**Relasi:** Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.