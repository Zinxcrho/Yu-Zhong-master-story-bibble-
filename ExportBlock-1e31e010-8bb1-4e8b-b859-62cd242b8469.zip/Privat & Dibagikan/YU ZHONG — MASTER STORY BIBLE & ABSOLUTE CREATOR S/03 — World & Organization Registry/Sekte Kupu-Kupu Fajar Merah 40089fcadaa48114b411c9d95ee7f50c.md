# Sekte Kupu-Kupu Fajar Merah

Category: Sekte Kecil
Counted in 838: Yes
History: Wilayahnya pernah dilanda bencana spiritual; tata pemerintahan dan pertahanannya dibangun ulang sesudahnya.
Last Updated Chapter: 0
Leader: Kepala Sekte Dao Kai
Notes: Entitas ke-162 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan yang dapat dikembangkan: Sekte Kabut Angin Purba dan Sekte Lentera Fajar Merah; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Jaringan informasi dan penguasaan jalur perjalanan memberinya pengaruh melebihi ukuran wilayahnya. Sumber daya utama: pasar artefak, bengkel pandai besi, dan pengrajin jimat.
Registry ID: ORG-245
Status: Aktif
Territory or Location: Pegunungan Pualam
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile