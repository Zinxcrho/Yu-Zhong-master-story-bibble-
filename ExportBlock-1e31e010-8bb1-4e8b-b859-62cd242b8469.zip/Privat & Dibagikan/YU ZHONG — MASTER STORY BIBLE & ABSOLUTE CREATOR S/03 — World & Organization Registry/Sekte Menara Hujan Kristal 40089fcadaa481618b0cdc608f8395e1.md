# Sekte Menara Hujan Kristal

Category: Sekte Kecil
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Kepala Sekte Ren Tao
Notes: Entitas ke-340 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan yang dapat dikembangkan: Sekte Teratai Cahaya Lembayung dan Sekte Pedang Bayang Timur; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-423
Status: Aktif
Territory or Location: Dataran Cermin
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile