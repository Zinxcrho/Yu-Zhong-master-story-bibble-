# Sekte Rasi Abadi

Category: Sekte Besar
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Patriark Agung Cen Yue
Notes: Entitas ke-14 dari 20 sekte besar kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan khusus yang dapat dikembangkan: Sekte Bangau Embun Giok dan Sekte Macan Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-77
Status: Aktif
Territory or Location: Lereng Bintang Jatuh
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-14 dari 20 sekte besar kanonis.

**Kawasan:** Lereng Bintang Jatuh.

**Watak kekuatan:** Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa.

**Sumber daya:** hutan binatang roh, bahan kulit, tulang, dan inti monster.

**Sejarah:** Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.

**Relasi:** Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.