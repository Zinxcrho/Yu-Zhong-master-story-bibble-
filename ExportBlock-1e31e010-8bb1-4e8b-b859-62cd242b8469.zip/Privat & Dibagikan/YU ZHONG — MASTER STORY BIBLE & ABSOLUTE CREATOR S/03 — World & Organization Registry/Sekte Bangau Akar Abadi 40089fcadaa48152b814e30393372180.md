# Sekte Bangau Akar Abadi

Category: Sekte Kecil
Counted in 838: Yes
History: Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.
Last Updated Chapter: 0
Leader: Kepala Sekte Lin Yu
Notes: Entitas ke-431 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan yang dapat dikembangkan: Sekte Gunung Pualam Kelam dan Sekte Bambu Akar Abadi; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi. Sumber daya utama: perpustakaan teknik, prasasti leluhur, dan arsip silsilah.
Registry ID: ORG-514
Status: Aktif
Territory or Location: Tanah Pintu Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile