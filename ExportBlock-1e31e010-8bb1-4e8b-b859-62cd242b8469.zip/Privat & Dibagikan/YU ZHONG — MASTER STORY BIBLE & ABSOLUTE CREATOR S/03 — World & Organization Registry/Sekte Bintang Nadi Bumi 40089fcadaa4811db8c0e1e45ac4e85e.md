# Sekte Bintang Nadi Bumi

Category: Sekte Kecil
Counted in 838: Yes
History: Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.
Last Updated Chapter: 0
Leader: Kepala Sekte Qin He
Notes: Entitas ke-721 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Kekaisaran Sembilan Bara dan Sekte Phoenix Sayap Senja; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi. Sumber daya utama: perpustakaan teknik, prasasti leluhur, dan arsip silsilah.
Registry ID: ORG-804
Status: Aktif
Territory or Location: Hutan Kristal
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile