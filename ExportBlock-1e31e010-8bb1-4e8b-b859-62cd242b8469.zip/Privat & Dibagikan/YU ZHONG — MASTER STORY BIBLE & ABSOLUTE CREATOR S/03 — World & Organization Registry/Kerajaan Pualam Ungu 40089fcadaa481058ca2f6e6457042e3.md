# Kerajaan Pualam Ungu

Category: Kerajaan
Counted in 838: Yes
History: Didirikan setelah beberapa klan perintis menyatukan wilayah yang terpecah oleh perang perbatasan.
Last Updated Chapter: 0
Leader: Raja Zhao Yue
Notes: Entitas ke-41 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan khusus yang dapat dikembangkan: Sekte Menara Awan Senja dan Sekte Alkimia Embun Emas; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pertahanan wilayah dan disiplin formasi menjadi keunggulan utama; kekuatan lapangan bergantung pada sumber daya setempat. Sumber daya utama: urat bijih spiritual, tambang giok, dan jalur kafilah.
Registry ID: ORG-61
Status: Aktif
Territory or Location: Hutan Seribu Akar
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-41 dari 43 kerajaan kanonis.

**Kawasan:** Hutan Seribu Akar.

**Watak kekuatan:** Pertahanan wilayah dan disiplin formasi menjadi keunggulan utama; kekuatan lapangan bergantung pada sumber daya setempat.

**Sumber daya:** urat bijih spiritual, tambang giok, dan jalur kafilah.

**Sejarah:** Didirikan setelah beberapa klan perintis menyatukan wilayah yang terpecah oleh perang perbatasan.

**Relasi:** Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.