# Sekte Batu Bintang Retak

Category: Sekte Kecil
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Kepala Sekte Mu Kai
Notes: Entitas ke-120 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Memiliki persaingan lama terkait sumber daya, tetapi kedua pihak masih mematuhi perjanjian perbatasan. Hubungan yang dapat dikembangkan: Sekte Macan Fajar Merah dan Sekte Kura-Kura Rembulan Pucat; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-203
Status: Aktif
Territory or Location: Dataran Salju Utara
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile