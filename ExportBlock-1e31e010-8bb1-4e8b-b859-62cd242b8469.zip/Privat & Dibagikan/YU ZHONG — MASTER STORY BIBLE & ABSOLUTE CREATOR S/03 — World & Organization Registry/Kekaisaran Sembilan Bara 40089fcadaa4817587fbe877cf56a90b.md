# Kekaisaran Sembilan Bara

Category: Kekaisaran
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Kaisar Mu Zhen
Notes: Entitas ke-3 dari 20 kekaisaran kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Memiliki persaingan lama terkait sumber daya, tetapi kedua pihak masih mematuhi perjanjian perbatasan. Hubungan khusus yang dapat dikembangkan: Kerajaan Pesisir Naga dan Kekaisaran Kabut Merah; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-3
Status: Aktif
Territory or Location: Dataran Cermin
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-3 dari 20 kekaisaran kanonis.

**Kawasan:** Dataran Cermin.

**Watak kekuatan:** Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan.

**Sumber daya:** mata air Qi pekat serta gua meditasi alami.

**Sejarah:** Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.

**Relasi:** Memiliki persaingan lama terkait sumber daya, tetapi kedua pihak masih mematuhi perjanjian perbatasan.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.