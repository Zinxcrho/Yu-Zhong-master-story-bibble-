# Sekte Teratai Sayap Senja

Category: Sekte Kecil
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Kepala Sekte Ning He
Notes: Entitas ke-727 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan yang dapat dikembangkan: Kekaisaran Rembulan Biru dan Sekte Menara Sayap Senja; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-810
Status: Aktif
Territory or Location: Dataran Bambu
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile