# Kerajaan Lembayung

Category: Kerajaan
Counted in 838: Yes
History: Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.
Last Updated Chapter: 0
Leader: Raja Lei Zhen
Notes: Entitas ke-22 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan khusus yang dapat dikembangkan: Sekte Guntur Tujuh Langkah dan Kerajaan Kaca Hitam; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu. Sumber daya utama: ladang ramuan obat, kebun roh, dan ahli alkimia.
Registry ID: ORG-42
Status: Aktif
Territory or Location: Lembah Angin Sunyi
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-22 dari 43 kerajaan kanonis.

**Kawasan:** Lembah Angin Sunyi.

**Watak kekuatan:** Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu.

**Sumber daya:** ladang ramuan obat, kebun roh, dan ahli alkimia.

**Sejarah:** Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.

**Relasi:** Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.