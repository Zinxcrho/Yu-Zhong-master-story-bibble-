# Armada Pengelana Bintang

Category: Kelompok Independen
Counted in 838: No
History: Memiliki piagam pendirian yang menekankan netralitas dan pencatatan transaksi.
Last Updated Chapter: 0
Leader: Pengelola Gu Qing
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menjelajah jalur berbahaya tanpa tunduk pada satu kerajaan. Sumber daya utama: mata air Qi dan fasilitas meditasi.
Registry ID: ORG-866
Status: Aktif
Territory or Location: Lautan Awan Purba
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menjelajah jalur berbahaya tanpa tunduk pada satu kerajaan.

**Kawasan:** Lautan Awan Purba.

**Sumber daya atau fungsi:** mata air Qi dan fasilitas meditasi.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.