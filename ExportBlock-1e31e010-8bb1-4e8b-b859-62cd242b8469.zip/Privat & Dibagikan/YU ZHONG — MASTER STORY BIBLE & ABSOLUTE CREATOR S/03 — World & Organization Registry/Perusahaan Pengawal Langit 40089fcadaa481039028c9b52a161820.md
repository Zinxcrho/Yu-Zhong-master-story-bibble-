# Perusahaan Pengawal Langit

Category: Perdagangan
Counted in 838: No
History: Memiliki piagam pendirian yang menekankan netralitas dan pencatatan transaksi.
Last Updated Chapter: 0
Leader: Pengelola Gu Yue
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menyediakan pengawal ekspedisi berdasarkan kontrak dan tingkat risiko. Sumber daya utama: bengkel, gudang, dan tenaga ahli.
Registry ID: ORG-856
Status: Aktif
Territory or Location: Dataran Arunika
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menyediakan pengawal ekspedisi berdasarkan kontrak dan tingkat risiko.

**Kawasan:** Dataran Arunika.

**Sumber daya atau fungsi:** bengkel, gudang, dan tenaga ahli.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.