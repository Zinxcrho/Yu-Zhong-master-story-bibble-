# Kerajaan Burung Api

Category: Kerajaan
Counted in 838: Yes
History: Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.
Last Updated Chapter: 0
Leader: Raja Lu Zhen
Notes: Entitas ke-4 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh. Hubungan khusus yang dapat dikembangkan: Kerajaan Pualam Ungu dan Kerajaan Serigala Putih; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi. Sumber daya utama: perpustakaan teknik, prasasti leluhur, dan arsip silsilah.
Registry ID: ORG-24
Status: Aktif
Territory or Location: Hutan Kristal
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-4 dari 43 kerajaan kanonis.

**Kawasan:** Hutan Kristal.

**Watak kekuatan:** Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi.

**Sumber daya:** perpustakaan teknik, prasasti leluhur, dan arsip silsilah.

**Sejarah:** Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.

**Relasi:** Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.