# Sekte Akar Rembulan Pucat

Category: Sekte Kecil
Counted in 838: Yes
History: Didirikan setelah beberapa klan perintis menyatukan wilayah yang terpecah oleh perang perbatasan.
Last Updated Chapter: 0
Leader: Kepala Sekte An Kai
Notes: Entitas ke-148 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan yang dapat dikembangkan: Sekte Qilin Angin Purba dan Sekte Serigala Fajar Merah; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pertahanan wilayah dan disiplin formasi menjadi keunggulan utama; kekuatan lapangan bergantung pada sumber daya setempat. Sumber daya utama: urat bijih spiritual, tambang giok, dan jalur kafilah.
Registry ID: ORG-231
Status: Aktif
Territory or Location: Pesisir Lonceng
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile