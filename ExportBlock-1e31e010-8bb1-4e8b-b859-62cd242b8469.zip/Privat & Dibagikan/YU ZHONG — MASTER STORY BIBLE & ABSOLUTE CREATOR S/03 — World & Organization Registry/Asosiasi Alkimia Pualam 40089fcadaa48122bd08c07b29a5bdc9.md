# Asosiasi Alkimia Pualam

Category: Asosiasi
Counted in 838: No
History: Mewarisi tradisi lama yang beberapa bagiannya masih diperdebatkan.
Last Updated Chapter: 0
Leader: Pengelola Ning Yue
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Menilai resep obat, mutu pil, dan standar keselamatan laboratorium. Sumber daya utama: jalur logistik dan kontrak perlindungan.
Registry ID: ORG-857
Status: Aktif
Territory or Location: Kota Awan Pualam
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Menilai resep obat, mutu pil, dan standar keselamatan laboratorium.

**Kawasan:** Kota Awan Pualam.

**Sumber daya atau fungsi:** jalur logistik dan kontrak perlindungan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.