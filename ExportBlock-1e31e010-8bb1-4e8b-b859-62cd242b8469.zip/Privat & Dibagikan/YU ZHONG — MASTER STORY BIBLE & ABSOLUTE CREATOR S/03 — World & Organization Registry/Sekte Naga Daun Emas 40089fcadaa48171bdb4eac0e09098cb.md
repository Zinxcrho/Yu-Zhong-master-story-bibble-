# Sekte Naga Daun Emas

Category: Sekte Kecil
Counted in 838: Yes
History: Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.
Last Updated Chapter: 0
Leader: Kepala Sekte Gu Bo
Notes: Entitas ke-226 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan yang dapat dikembangkan: Sekte Lonceng Petir Sunyi dan Sekte Cermin Daun Emas; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman. Sumber daya utama: tambang kristal, batu formasi, dan laboratorium riset.
Registry ID: ORG-309
Status: Aktif
Territory or Location: Lembah Fajar Terakhir
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile