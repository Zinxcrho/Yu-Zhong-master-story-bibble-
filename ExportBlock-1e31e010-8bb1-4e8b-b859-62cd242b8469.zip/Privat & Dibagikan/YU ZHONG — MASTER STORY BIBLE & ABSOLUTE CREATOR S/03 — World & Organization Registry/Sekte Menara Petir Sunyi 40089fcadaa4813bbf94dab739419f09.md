# Sekte Menara Petir Sunyi

Category: Sekte Kecil
Counted in 838: Yes
History: Arsipnya menyimpan sengketa lama yang penyelesaiannya masih diperdebatkan oleh para sejarawan.
Last Updated Chapter: 0
Leader: Kepala Sekte Lan Bo
Notes: Entitas ke-265 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Sekte Teratai Pasir Surgawi dan Sekte Pedang Salju Arunika; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Keahlian khususnya adalah pengolahan bahan spiritual, tetapi hasilnya dibatasi musim dan kualitas bahan baku. Sumber daya utama: formasi pelindung wilayah serta menara pengawas.
Registry ID: ORG-348
Status: Aktif
Territory or Location: Lautan Giok Timur
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile