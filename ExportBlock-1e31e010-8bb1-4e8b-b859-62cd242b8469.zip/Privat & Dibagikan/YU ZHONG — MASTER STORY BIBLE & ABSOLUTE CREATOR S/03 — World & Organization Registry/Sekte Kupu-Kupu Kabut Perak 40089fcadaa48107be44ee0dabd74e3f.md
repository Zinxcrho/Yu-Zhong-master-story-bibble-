# Sekte Kupu-Kupu Kabut Perak

Category: Sekte Kecil
Counted in 838: Yes
History: Wilayahnya pernah dilanda bencana spiritual; tata pemerintahan dan pertahanannya dibangun ulang sesudahnya.
Last Updated Chapter: 0
Leader: Kepala Sekte Dao Qing
Notes: Entitas ke-62 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan yang dapat dikembangkan: Sekte Kabut Bara Biru dan Sekte Lentera Kabut Perak; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Jaringan informasi dan penguasaan jalur perjalanan memberinya pengaruh melebihi ukuran wilayahnya. Sumber daya utama: pasar artefak, bengkel pandai besi, dan pengrajin jimat.
Registry ID: ORG-145
Status: Aktif
Territory or Location: Gurun Zamrud
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile