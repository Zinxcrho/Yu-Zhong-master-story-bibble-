# Hutan Binatang Roh

Category: Lokasi
Counted in 838: No
History: Mengalami reformasi setelah insiden yang mengubah tata kelola mereka.
Last Updated Chapter: 0
Leader: Tidak berlaku
Notes: Lokasi tambahan di luar hitungan 838 organisasi. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Akses dan pengaruh bergantung pada kondisi wilayah serta izin yang berlaku.
Power Base and Resources: Habitat beragam binatang roh dengan zona aman dan zona berbahaya yang berubah musiman. Sumber daya utama: jaringan kurir dan informasi terverifikasi.
Registry ID: ORG-883
Status: Aktif
Territory or Location: Hutan Seribu Akar
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Habitat beragam binatang roh dengan zona aman dan zona berbahaya yang berubah musiman.

**Kawasan:** Hutan Seribu Akar.

**Sumber daya atau fungsi:** jaringan kurir dan informasi terverifikasi.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.