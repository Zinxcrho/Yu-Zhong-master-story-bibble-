# Serikat Tabib Jiwa

Category: Asosiasi
Counted in 838: No
History: Berkembang secara bertahap dari komunitas kecil dan jaringan kepercayaan.
Last Updated Chapter: 0
Leader: Pengelola Mu Qing
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Mengembangkan metode pemulihan yang tidak bergantung pada satu sekte. Sumber daya utama: kebun ramuan dan laboratorium.
Registry ID: ORG-860
Status: Aktif
Territory or Location: Kota Lembah Giok
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Mengembangkan metode pemulihan yang tidak bergantung pada satu sekte.

**Kawasan:** Kota Lembah Giok.

**Sumber daya atau fungsi:** kebun ramuan dan laboratorium.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.