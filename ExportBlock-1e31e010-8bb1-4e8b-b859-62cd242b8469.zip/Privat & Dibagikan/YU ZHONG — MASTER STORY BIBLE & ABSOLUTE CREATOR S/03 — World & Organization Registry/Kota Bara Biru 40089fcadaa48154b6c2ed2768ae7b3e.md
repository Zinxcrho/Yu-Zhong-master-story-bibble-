# Kota Bara Biru

Category: Lokasi
Counted in 838: No
History: Berkembang secara bertahap dari komunitas kecil dan jaringan kepercayaan.
Last Updated Chapter: 0
Leader: Tidak berlaku
Notes: Lokasi tambahan di luar hitungan 838 organisasi. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Akses dan pengaruh bergantung pada kondisi wilayah serta izin yang berlaku.
Power Base and Resources: Pusat peleburan logam spiritual yang bergantung pada mata air panas. Sumber daya utama: jaringan kurir dan informasi terverifikasi.
Registry ID: ORG-875
Status: Aktif
Territory or Location: Lembah Bara Biru
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Pusat peleburan logam spiritual yang bergantung pada mata air panas.

**Kawasan:** Lembah Bara Biru.

**Sumber daya atau fungsi:** jaringan kurir dan informasi terverifikasi.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.