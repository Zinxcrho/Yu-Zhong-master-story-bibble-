# Sekte Qilin Embun Giok

Category: Sekte Kecil
Counted in 838: Yes
History: Arsipnya menyimpan sengketa lama yang penyelesaiannya masih diperdebatkan oleh para sejarawan.
Last Updated Chapter: 0
Leader: Kepala Sekte Duan Qing
Notes: Entitas ke-35 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan yang dapat dikembangkan: Sekte Bulan Kabut Perak dan Sekte Akar Embun Giok; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Keahlian khususnya adalah pengolahan bahan spiritual, tetapi hasilnya dibatasi musim dan kualitas bahan baku. Sumber daya utama: formasi pelindung wilayah serta menara pengawas.
Registry ID: ORG-118
Status: Aktif
Territory or Location: Dataran Teratai
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile