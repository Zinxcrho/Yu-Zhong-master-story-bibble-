# Dewan Penilai Artefak

Category: Asosiasi
Counted in 838: No
History: Memiliki piagam pendirian yang menekankan netralitas dan pencatatan transaksi.
Last Updated Chapter: 0
Leader: Pengelola Qin Qing
Notes: Organisasi tambahan di luar hitungan 838 entitas inti. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Berhubungan dengan faksi lain melalui kontrak; tidak memiliki loyalitas otomatis kepada kekaisaran atau sekte.
Power Base and Resources: Memeriksa keaslian artefak dan memperingatkan pembeli tentang kutukan yang terdeteksi. Sumber daya utama: sarana penginapan dan perdagangan.
Registry ID: ORG-861
Status: Aktif
Territory or Location: Kota Pasar Seribu Lampu
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Memeriksa keaslian artefak dan memperingatkan pembeli tentang kutukan yang terdeteksi.

**Kawasan:** Kota Pasar Seribu Lampu.

**Sumber daya atau fungsi:** sarana penginapan dan perdagangan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.