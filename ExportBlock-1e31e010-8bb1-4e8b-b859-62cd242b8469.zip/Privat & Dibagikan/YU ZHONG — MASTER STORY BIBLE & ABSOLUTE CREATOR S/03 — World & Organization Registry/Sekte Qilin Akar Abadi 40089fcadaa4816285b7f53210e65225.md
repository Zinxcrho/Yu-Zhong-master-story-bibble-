# Sekte Qilin Akar Abadi

Category: Sekte Kecil
Counted in 838: Yes
History: Arsipnya menyimpan sengketa lama yang penyelesaiannya masih diperdebatkan oleh para sejarawan.
Last Updated Chapter: 0
Leader: Kepala Sekte Duan Yu
Notes: Entitas ke-435 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan yang dapat dikembangkan: Sekte Bulan Pualam Kelam dan Sekte Akar Akar Abadi; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Keahlian khususnya adalah pengolahan bahan spiritual, tetapi hasilnya dibatasi musim dan kualitas bahan baku. Sumber daya utama: formasi pelindung wilayah serta menara pengawas.
Registry ID: ORG-518
Status: Aktif
Territory or Location: Hulu Sungai Abadi
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile