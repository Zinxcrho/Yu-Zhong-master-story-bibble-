# Sekte Rusa Awan Senja

Category: Sekte Kecil
Counted in 838: Yes
History: Arsipnya menyimpan sengketa lama yang penyelesaiannya masih diperdebatkan oleh para sejarawan.
Last Updated Chapter: 0
Leader: Kepala Sekte Xiang Yue
Notes: Entitas ke-5 dari 755 sekte kecil kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh. Hubungan khusus yang dapat dikembangkan: Sekte Sungai Embun Giok dan Sekte Gunung Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Keahlian khususnya adalah pengolahan bahan spiritual, tetapi hasilnya dibatasi musim dan kualitas bahan baku. Sumber daya utama: formasi pelindung wilayah serta menara pengawas.
Registry ID: ORG-88
Status: Aktif
Territory or Location: Dataran Teratai
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-5 dari 755 sekte kecil kanonis.

**Kawasan:** Dataran Teratai.

**Watak kekuatan:** Keahlian khususnya adalah pengolahan bahan spiritual, tetapi hasilnya dibatasi musim dan kualitas bahan baku.

**Sumber daya:** formasi pelindung wilayah serta menara pengawas.

**Sejarah:** Arsipnya menyimpan sengketa lama yang penyelesaiannya masih diperdebatkan oleh para sejarawan.

**Relasi:** Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.