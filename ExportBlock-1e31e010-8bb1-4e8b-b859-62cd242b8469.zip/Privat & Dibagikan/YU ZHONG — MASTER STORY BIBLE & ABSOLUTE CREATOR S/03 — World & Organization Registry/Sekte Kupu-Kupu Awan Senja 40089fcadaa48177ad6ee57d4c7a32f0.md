# Sekte Kupu-Kupu Awan Senja

Category: Sekte Kecil
Counted in 838: Yes
History: Wilayahnya pernah dilanda bencana spiritual; tata pemerintahan dan pertahanannya dibangun ulang sesudahnya.
Last Updated Chapter: 0
Leader: Kepala Sekte Dao Yue
Notes: Entitas ke-12 dari 755 sekte kecil kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan khusus yang dapat dikembangkan: Sekte Kabut Embun Giok dan Sekte Lentera Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Jaringan informasi dan penguasaan jalur perjalanan memberinya pengaruh melebihi ukuran wilayahnya. Sumber daya utama: pasar artefak, bengkel pandai besi, dan pengrajin jimat.
Registry ID: ORG-95
Status: Aktif
Territory or Location: Pegunungan Pualam
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-12 dari 755 sekte kecil kanonis.

**Kawasan:** Pegunungan Pualam.

**Watak kekuatan:** Jaringan informasi dan penguasaan jalur perjalanan memberinya pengaruh melebihi ukuran wilayahnya.

**Sumber daya:** pasar artefak, bengkel pandai besi, dan pengrajin jimat.

**Sejarah:** Wilayahnya pernah dilanda bencana spiritual; tata pemerintahan dan pertahanannya dibangun ulang sesudahnya.

**Relasi:** Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.