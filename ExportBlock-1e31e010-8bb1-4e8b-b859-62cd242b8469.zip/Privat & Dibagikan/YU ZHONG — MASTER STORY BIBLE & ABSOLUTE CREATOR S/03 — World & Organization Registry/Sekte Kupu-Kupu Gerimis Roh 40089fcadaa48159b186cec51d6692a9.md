# Sekte Kupu-Kupu Gerimis Roh

Category: Sekte Kecil
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Kepala Sekte Tang Ming
Notes: Entitas ke-537 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Sekte Kabut Badai Jingga dan Sekte Lentera Gerimis Roh; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-620
Status: Aktif
Territory or Location: Kawasan Rasi Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile