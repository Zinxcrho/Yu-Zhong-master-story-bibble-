# Sekte Bintang Serbuk Bintang

Category: Sekte Kecil
Counted in 838: Yes
History: Para pendiri memilih menjaga keseimbangan dengan tetangga daripada melakukan ekspansi militer.
Last Updated Chapter: 0
Leader: Kepala Sekte Yue Jue
Notes: Entitas ke-646 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan yang dapat dikembangkan: Sekte Kura-Kura Taring Perak dan Sekte Phoenix Lembah Sunyi; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Warisan tekniknya kuat, tetapi hanya sebagian naskah yang masih dapat digunakan dengan aman. Sumber daya utama: tambang kristal, batu formasi, dan laboratorium riset.
Registry ID: ORG-729
Status: Aktif
Territory or Location: Lembah Fajar Terakhir
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile