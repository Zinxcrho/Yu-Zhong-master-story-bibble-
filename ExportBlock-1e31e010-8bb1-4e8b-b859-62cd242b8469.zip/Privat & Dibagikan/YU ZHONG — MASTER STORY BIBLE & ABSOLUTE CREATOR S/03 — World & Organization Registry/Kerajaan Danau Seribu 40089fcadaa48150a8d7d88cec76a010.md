# Kerajaan Danau Seribu

Category: Kerajaan
Counted in 838: Yes
History: Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.
Last Updated Chapter: 0
Leader: Raja Jin Zhen
Notes: Entitas ke-2 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya. Hubungan khusus yang dapat dikembangkan: Kerajaan Naga Kabut dan Kerajaan Nadi Bumi; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu. Sumber daya utama: ladang ramuan obat, kebun roh, dan ahli alkimia.
Registry ID: ORG-22
Status: Aktif
Territory or Location: Dataran Arunika
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-2 dari 43 kerajaan kanonis.

**Kawasan:** Dataran Arunika.

**Watak kekuatan:** Pasukan terlatih dan logistik menjadi fondasi kekuatan; mereka tidak selalu unggul dalam duel satu lawan satu.

**Sumber daya:** ladang ramuan obat, kebun roh, dan ahli alkimia.

**Sejarah:** Tradisi setempat menyebut pendirinya menemukan prasasti yang belum sepenuhnya dapat diterjemahkan.

**Relasi:** Bersikap netral di antara kekuatan besar dan melindungi hak otonomi wilayahnya.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.