# Sekte Cakra Awan Senja

Category: Sekte Kecil
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Kepala Sekte Ming Yue
Notes: Entitas ke-4 dari 755 sekte kecil kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan khusus yang dapat dikembangkan: Sekte Gerbang Embun Giok dan Sekte Sungai Awan Senja; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-87
Status: Aktif
Territory or Location: Lembah Sungai Langit
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-4 dari 755 sekte kecil kanonis.

**Kawasan:** Lembah Sungai Langit.

**Watak kekuatan:** Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa.

**Sumber daya:** hutan binatang roh, bahan kulit, tulang, dan inti monster.

**Sejarah:** Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.

**Relasi:** Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.