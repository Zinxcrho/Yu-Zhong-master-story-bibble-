# Sekte Lonceng Petir Sunyi

Category: Sekte Kecil
Counted in 838: Yes
History: Sejarah lisannya mengenang seorang pengelana yang mengajarkan metode bertahan hidup, bukan teknik terlarang.
Last Updated Chapter: 0
Leader: Kepala Sekte Yao Bo
Notes: Entitas ke-263 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan yang dapat dikembangkan: Sekte Lentera Salju Arunika dan Sekte Naga Salju Arunika; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Ekonominya bergantung pada perdagangan dan perjanjian, sehingga konflik berkepanjangan akan merugikan mereka. Sumber daya utama: pelabuhan sungai, kapal dagang, dan gudang bahan spiritual.
Registry ID: ORG-346
Status: Aktif
Territory or Location: Pegunungan Matahari
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile