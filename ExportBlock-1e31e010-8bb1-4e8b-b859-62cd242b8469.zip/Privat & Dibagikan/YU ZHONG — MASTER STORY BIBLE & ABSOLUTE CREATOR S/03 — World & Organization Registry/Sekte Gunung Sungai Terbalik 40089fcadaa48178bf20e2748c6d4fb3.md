# Sekte Gunung Sungai Terbalik

Category: Sekte Kecil
Counted in 838: Yes
History: Didirikan setelah beberapa klan perintis menyatukan wilayah yang terpecah oleh perang perbatasan.
Last Updated Chapter: 0
Leader: Kepala Sekte Luo Yu
Notes: Entitas ke-418 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan yang dapat dikembangkan: Sekte Rusa Pualam Kelam dan Sekte Bangau Akar Abadi; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Pertahanan wilayah dan disiplin formasi menjadi keunggulan utama; kekuatan lapangan bergantung pada sumber daya setempat. Sumber daya utama: urat bijih spiritual, tambang giok, dan jalur kafilah.
Registry ID: ORG-501
Status: Aktif
Territory or Location: Pesisir Lonceng
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile