# Sekte Batu Gerimis Roh

Category: Sekte Kecil
Counted in 838: Yes
History: Arsipnya menyimpan sengketa lama yang penyelesaiannya masih diperdebatkan oleh para sejarawan.
Last Updated Chapter: 0
Leader: Kepala Sekte Qiao Ming
Notes: Entitas ke-545 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan yang dapat dikembangkan: Sekte Macan Langit Retak dan Sekte Kura-Kura Badai Jingga; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Keahlian khususnya adalah pengolahan bahan spiritual, tetapi hasilnya dibatasi musim dan kualitas bahan baku. Sumber daya utama: formasi pelindung wilayah serta menara pengawas.
Registry ID: ORG-628
Status: Aktif
Territory or Location: Dataran Teratai
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile