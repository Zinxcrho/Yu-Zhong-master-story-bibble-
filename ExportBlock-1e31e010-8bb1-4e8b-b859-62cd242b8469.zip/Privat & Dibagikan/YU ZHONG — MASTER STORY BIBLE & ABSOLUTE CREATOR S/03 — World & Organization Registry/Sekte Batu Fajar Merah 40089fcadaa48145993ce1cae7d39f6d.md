# Sekte Batu Fajar Merah

Category: Sekte Kecil
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Kepala Sekte Mu Xuan
Notes: Entitas ke-170 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan dengan sekte-sekte setempat bergantung pada kontrak, bukan loyalitas mutlak. Hubungan yang dapat dikembangkan: Sekte Macan Ombak Hitam dan Sekte Kura-Kura Angin Purba; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-253
Status: Aktif
Territory or Location: Kawasan Menara Tua
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile