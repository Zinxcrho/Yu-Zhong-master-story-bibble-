# Kerajaan Fajar Terakhir

Category: Kerajaan
Counted in 838: Yes
History: Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.
Last Updated Chapter: 0
Leader: Raja Han Yue
Notes: Entitas ke-43 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik. Hubungan khusus yang dapat dikembangkan: Sekte Sungai Awan Senja dan Sekte Tombak Fajar Merah; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan. Sumber daya utama: mata air Qi pekat serta gua meditasi alami.
Registry ID: ORG-63
Status: Aktif
Territory or Location: Dataran Cermin
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-43 dari 43 kerajaan kanonis.

**Kawasan:** Dataran Cermin.

**Watak kekuatan:** Penguasaan medan dan formasi pertahanan membuat wilayahnya sulit ditembus tanpa persiapan.

**Sumber daya:** mata air Qi pekat serta gua meditasi alami.

**Sejarah:** Pertumbuhannya berawal dari jalur perdagangan yang menghubungkan dua kawasan kultivasi.

**Relasi:** Menjadi penengah bagi dua tetangga yang berselisih; reputasi ini memberi pengaruh diplomatik.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.