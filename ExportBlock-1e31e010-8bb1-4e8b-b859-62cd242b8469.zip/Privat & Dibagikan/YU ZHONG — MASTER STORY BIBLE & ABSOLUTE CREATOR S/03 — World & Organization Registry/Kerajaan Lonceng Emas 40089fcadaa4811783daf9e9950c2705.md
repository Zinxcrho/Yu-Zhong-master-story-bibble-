# Kerajaan Lonceng Emas

Category: Kerajaan
Counted in 838: Yes
History: Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.
Last Updated Chapter: 0
Leader: Raja Bai Yue
Notes: Entitas ke-37 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka. Hubungan khusus yang dapat dikembangkan: Sekte Serigala Awan Senja dan Sekte Api Tanpa Bayang; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa. Sumber daya utama: hutan binatang roh, bahan kulit, tulang, dan inti monster.
Registry ID: ORG-57
Status: Aktif
Territory or Location: Lembah Sungai Langit
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-37 dari 43 kerajaan kanonis.

**Kawasan:** Lembah Sungai Langit.

**Watak kekuatan:** Artefak kuno menjadi aset penting, namun keaslian dan kondisi setiap relik harus diperiksa.

**Sumber daya:** hutan binatang roh, bahan kulit, tulang, dan inti monster.

**Sejarah:** Organisasi ini tumbuh dari komunitas kecil penjaga sumber daya dan berkembang secara bertahap.

**Relasi:** Menjaga hubungan dagang pragmatis dengan tetangga; sengketa diselesaikan melalui utusan sebelum perang terbuka.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.