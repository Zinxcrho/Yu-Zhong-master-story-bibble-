# Gurun Cermin Malam

Category: Lokasi
Counted in 838: No
History: Mewarisi tradisi lama yang beberapa bagiannya masih diperdebatkan.
Last Updated Chapter: 0
Leader: Tidak berlaku
Notes: Lokasi tambahan di luar hitungan 838 organisasi. Detail dapat berkembang berdasarkan peristiwa yang benar-benar terjadi.
Political Relations: Akses dan pengaruh bergantung pada kondisi wilayah serta izin yang berlaku.
Power Base and Resources: Hamparan kaca alam yang memantulkan bintang dan membingungkan pelancong. Sumber daya utama: arsip peta dan catatan perjalanan.
Registry ID: ORG-887
Status: Aktif
Territory or Location: Gurun Kaca Merah
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

**Profil:** Hamparan kaca alam yang memantulkan bintang dan membingungkan pelancong.

**Kawasan:** Gurun Kaca Merah.

**Sumber daya atau fungsi:** arsip peta dan catatan perjalanan.

**Kontinuitas:** Entitas ini merupakan bagian dari latar dunia bersama. Keterlibatan dalam alur utama atau Sandbox harus ditetapkan melalui kejadian yang benar-benar berlangsung.