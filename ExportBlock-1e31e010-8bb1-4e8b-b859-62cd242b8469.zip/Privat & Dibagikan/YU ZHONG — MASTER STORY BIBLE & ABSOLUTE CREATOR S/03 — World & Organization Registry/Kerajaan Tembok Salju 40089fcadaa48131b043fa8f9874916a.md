# Kerajaan Tembok Salju

Category: Kerajaan
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Raja Tian Zhen
Notes: Entitas ke-30 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan khusus yang dapat dikembangkan: Sekte Cakra Awan Senja dan Kerajaan Fajar Terakhir; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-50
Status: Aktif
Territory or Location: Kawasan Rasi Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-30 dari 43 kerajaan kanonis.

**Kawasan:** Kawasan Rasi Selatan.

**Watak kekuatan:** Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka.

**Sumber daya:** ladang pangan, kanal, dan jaringan logistik.

**Sejarah:** Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.

**Relasi:** Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.