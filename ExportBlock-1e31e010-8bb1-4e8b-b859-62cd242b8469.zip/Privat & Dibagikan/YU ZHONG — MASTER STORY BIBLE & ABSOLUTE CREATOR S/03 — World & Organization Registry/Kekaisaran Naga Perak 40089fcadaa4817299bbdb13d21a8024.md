# Kekaisaran Naga Perak

Category: Kekaisaran
Counted in 838: Yes
History: Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.
Last Updated Chapter: 0
Leader: Kaisar Qin Zhen
Notes: Entitas ke-4 dari 20 kekaisaran kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor. Hubungan khusus yang dapat dikembangkan: Kerajaan Menara Tua dan Kekaisaran Gurun Zamrud; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi. Sumber daya utama: perpustakaan teknik, prasasti leluhur, dan arsip silsilah.
Registry ID: ORG-4
Status: Aktif
Territory or Location: Tanah Pintu Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-4 dari 20 kekaisaran kanonis.

**Kawasan:** Tanah Pintu Selatan.

**Watak kekuatan:** Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi.

**Sumber daya:** perpustakaan teknik, prasasti leluhur, dan arsip silsilah.

**Sejarah:** Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.

**Relasi:** Hubungan politiknya berubah-ubah mengikuti pergantian pemimpin, tetapi kepentingan rakyat tetap menjadi faktor.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.