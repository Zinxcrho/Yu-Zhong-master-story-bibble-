# Sekte Kupu-Kupu Daun Emas

Category: Sekte Kecil
Counted in 838: Yes
History: Perubahan besar terakhir terjadi ketika generasi pemimpin baru mereformasi aturan suksesi.
Last Updated Chapter: 0
Leader: Kepala Sekte Tang Bo
Notes: Entitas ke-237 dari 755 sekte kecil kanonis. Profil orisinal berbasis konvensi xianxia: hierarki kultivasi, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Menjalin kerja sama terbatas dalam pengawalan jalur dagang dan penanganan binatang roh. Hubungan yang dapat dikembangkan: Sekte Kabut Petir Sunyi dan Sekte Lentera Daun Emas; ini belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Para anggotanya unggul dalam riset, penyembuhan, dan dukungan; mereka cenderung menghindari perang terbuka. Sumber daya utama: ladang pangan, kanal, dan jaringan logistik.
Registry ID: ORG-320
Status: Aktif
Territory or Location: Kawasan Rasi Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile