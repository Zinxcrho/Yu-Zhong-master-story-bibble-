# Kerajaan Hujan Giok

Category: Kerajaan
Counted in 838: Yes
History: Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.
Last Updated Chapter: 0
Leader: Raja Fang Zhen
Notes: Entitas ke-14 dari 43 kerajaan kanonis. Profil awal berbasis konvensi genre xianxia: hierarki kekuatan, ekonomi sumber daya, teknik, relik, dan politik. Bukan salinan langsung karya lain.
Political Relations: Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya. Hubungan khusus yang dapat dikembangkan: Sekte Bulan Kembar dan Kerajaan Hutan Merah; hubungan belum otomatis menjadi aliansi atau perang.
Power Base and Resources: Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi. Sumber daya utama: perpustakaan teknik, prasasti leluhur, dan arsip silsilah.
Registry ID: ORG-34
Status: Aktif
Territory or Location: Tanah Pintu Selatan
Timeline ID: WORLD-BASE
Timeline Scope: Shared Base Profile

## Profil kanonis

Entitas ke-14 dari 43 kerajaan kanonis.

**Kawasan:** Tanah Pintu Selatan.

**Watak kekuatan:** Kekuatan utamanya tersebar di banyak cabang, sehingga koordinasi internal sama pentingnya dengan kultivasi.

**Sumber daya:** perpustakaan teknik, prasasti leluhur, dan arsip silsilah.

**Sejarah:** Catatan tertua menyebut perjanjian damai yang masih menjadi dasar hukum wilayah hingga kini.

**Relasi:** Mengirim pengamat ke pertemuan regional dan menghindari persekutuan permanen yang membatasi geraknya.

**Aturan kontinuitas:** Organisasi ini merupakan entitas orisinal dunia Yu Zhong. Detail baru harus mengikuti peristiwa yang benar-benar terjadi; jangan menganggap Yu Zhong telah bertemu atau mengetahui organisasi ini sebelum ada dasar dalam cerita.